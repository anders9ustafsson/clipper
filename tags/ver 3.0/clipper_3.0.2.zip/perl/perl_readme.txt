
A Perl module written by Steffen M�ller < smueller@cpan.org > 
that wraps the Clipper library can be downloaded from:

http://cpansearch.perl.org/src/SMUELLER/Math-Clipper-0.01/